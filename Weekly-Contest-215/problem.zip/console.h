#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

string rline();
int rint();
long long rlong();
void rvector(vector<int> & x);
char rchar();